ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local weaponIcons = {
    ["WEAPON_PISTOL"] = "CHAR_LAMAR",
    ["WEAPON_COMBATPISTOL"] = "CHAR_LAMAR",
    ["WEAPON_APPISTOL"] = "CHAR_LAMAR",
    ["WEAPON_PISTOL50"] = "CHAR_LAMAR",
    ["WEAPON_REVOLVER"] = "CHAR_LAMAR",
    ["WEAPON_SNSPISTOL"] = "CHAR_LAMAR",
    ["WEAPON_MICROSMG"] = "CHAR_LAMAR",
    ["WEAPON_SMG"] = "CHAR_LAMAR",
    ["WEAPON_ASSAULTSMG"] = "CHAR_LAMAR",
    ["WEAPON_COMBATPDW"] = "CHAR_LAMAR",
    ["WEAPON_ASSAULTRIFLE"] = "CHAR_LAMAR",
    ["WEAPON_CARBINERIFLE"] = "CHAR_LAMAR",
    ["WEAPON_ADVANCEDRIFLE"] = "CHAR_LAMAR",
    ["WEAPON_SPECIALCARBINE"] = "CHAR_LAMAR",
    ["WEAPON_BULLPUPRIFLE"] = "CHAR_LAMAR",
    ["WEAPON_MG"] = "CHAR_LAMAR",
    ["WEAPON_COMBATMG"] = "CHAR_LAMAR",
    ["WEAPON_SNIPERRIFLE"] = "CHAR_LAMAR",
    ["WEAPON_HEAVYSNIPER"] = "CHAR_LAMAR",
    ["WEAPON_MARKSMANRIFLE"] = "CHAR_LAMAR",
    ["WEAPON_RPG"] = "CHAR_LAMAR",
    ["WEAPON_GRENADELAUNCHER"] = "CHAR_LAMAR",
    ["WEAPON_STINGER"] = "CHAR_LAMAR",
    ["WEAPON_MINIGUN"] = "CHAR_LAMAR",
    ["WEAPON_FLAREGUN"] = "CHAR_LAMAR",
    ["WEAPON_FIREWORK"] = "CHAR_LAMAR",
    ["WEAPON_PUMPSHOTGUN"] = "CHAR_LAMAR",
    ["WEAPON_SAWNOFFSHOTGUN"] = "CHAR_LAMAR",
    ["WEAPON_BULLPUPSHOTGUN"] = "CHAR_LAMAR",
    ["WEAPON_ASSAULTSHOTGUN"] = "CHAR_LAMAR",
    ["WEAPON_NIGHTSTICK"] = "CHAR_LAMAR",
    ["WEAPON_HAMMER"] = "CHAR_LAMAR",
    ["WEAPON_BAT"] = "CHAR_LAMAR",
    ["WEAPON_CROWBAR"] = "CHAR_LAMAR",
    ["WEAPON_GOLFCLUB"] = "CHAR_LAMAR",
    ["WEAPON_MOLOTOV"] = "CHAR_LAMAR",
    ["WEAPON_BZGAS"] = "CHAR_LAMAR",
    ["WEAPON_SNOWBALL"] = "CHAR_LAMAR",
    ["WEAPON_KNIFE"] = "CHAR_LAMAR",
    ["WEAPON_DAGGER"] = "CHAR_LAMAR",
    ["WEAPON_HATCHET"] = "CHAR_LAMAR",
    ["WEAPON_MACHETE"] = "CHAR_LAMAR",
    ["WEAPON_BATTLEAXE"] = "CHAR_LAMAR",
    ["WEAPON_POOLCUE"] = "CHAR_LAMAR",
}

RegisterCommand('dajbron', function(source, args, rawCommand)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if xPlayer then
        local id = tonumber(args[1])
        local weapon = args[2]
        local quantity = tonumber(args[3])
        
        if id and weapon and quantity then
            local targetPlayer = ESX.GetPlayerFromId(id)
            
            if targetPlayer then
                if weaponIcons[weapon] then
                    targetPlayer.addWeapon(weapon, quantity)
                    local icon = weaponIcons[weapon] or "CHAR_LAMAR"
                    TriggerClientEvent('esx:showAdvancedNotification', id, 'Broń otrzymana', 'Otrzymałeś broń: ' .. weapon .. ' x' .. quantity, weapon, icon)
                    TriggerClientEvent('esx:showAdvancedNotification', source, 'Broń przekazana', 'Pomyślnie przekazałeś broń: ' .. weapon .. ' x' .. quantity .. ' do gracza ' .. id, weapon, icon)
                else
                    TriggerClientEvent('esx:showNotification', source, 'Nieprawidłowy model broni')
                end
            else
                TriggerClientEvent('esx:showNotification', source, 'Nie znaleziono gracza o ID ' .. id)
            end
        else
            TriggerClientEvent('esx:showNotification', source, 'Użycie: /dajbron <id> <model broni> <ilość>')
        end
    end
end, false)
